"""
WSGI config for lazer project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/5.2/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'lazer.settings')

from core.healthcheck import HealthcheckWSGI

application = HealthcheckWSGI(get_wsgi_application())
