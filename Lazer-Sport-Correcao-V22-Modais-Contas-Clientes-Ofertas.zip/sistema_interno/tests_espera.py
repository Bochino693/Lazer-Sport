"""Esperar não pode virar erro, e voltar depois tem de ser rápido.

O QUE ACONTECIA. A hospedagem desliga a instância depois de alguns
minutos sem nenhuma requisição. O painel tem um pulso -- a central de
avisos pergunta de 30 em 30 segundos --, mas ele só bate com a ABA
VISÍVEL. Painel aberto numa aba de fundo, ou com a tela bloqueada, é
painel sem pulso: a instância dorme.

Aí a pessoa volta, clica em "Salvar", e é esse clique que paga a conta de
acordar processo web e conexão de banco. São dezenas de segundos.
Passando de 90, o gunicorn mata o worker e o que volta é 502.
"""

from pathlib import Path

from django.contrib.auth.models import User
from django.test import SimpleTestCase, TestCase, override_settings

RAIZ = Path(__file__).resolve().parent


@override_settings(ALLOWED_HOSTS=["interno.testserver", "testserver"])
class DespertarTests(TestCase):

    def test_pronto_acorda_processo_e_banco(self):
        """Acordar só o processo trocaria espera longa por espera média.

        O primeiro clique de quem volta ao painel vai consultar o banco, e
        abrir conexão nova com o Supabase custa segundos. Por isso este
        endereço toca o banco, ao contrário do `healthz`.
        """
        with self.assertNumQueries(1):
            resposta = self.client.get("/pronto/", HTTP_HOST="testserver")

        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(resposta.json(), {"ok": True, "banco": True})

    def test_pronto_responde_sem_login(self):
        """Ele é chamado justamente quando a sessão pode ter caído."""
        resposta = self.client.get("/pronto/", HTTP_HOST="testserver")
        self.assertEqual(resposta.status_code, 200)

    def test_o_healthz_da_hospedagem_continua_sem_tocar_no_banco(self):
        """Se ele dependesse do banco, uma oscilação derrubaria o processo.

        E um processo derrubado não volta mais rápido por isso -- volta
        mais devagar, porque precisa subir tudo de novo.
        """
        with self.assertNumQueries(0):
            resposta = self.client.get("/healthz/", HTTP_HOST="testserver")

        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(resposta.content, b"ok")

    def test_a_equipe_logada_tambem_alcanca(self):
        User.objects.create_superuser("espera", "e@e.com", "x")
        self.client.login(username="espera", password="x")
        self.assertEqual(
            self.client.get("/pronto/", HTTP_HOST="testserver").status_code, 200,
        )


class AcordarAntesDeAgirTests(SimpleTestCase):
    """O POST espera o servidor acordar, em vez de falhar contra ele."""

    @staticmethod
    def painel():
        return (RAIZ / "static" / "interno" / "painel.js").read_text(encoding="utf-8")

    def test_o_post_nunca_e_repetido_as_cegas(self):
        """Ele pode ter chegado e sido gravado; só a resposta se perdeu.

        Repetir criaria a segunda proposta, o segundo pagamento. Quem
        repete é o GET de acordar, que é seguro repetir.
        """
        painel = self.painel()

        self.assertIn("POST único", painel)
        self.assertIn("Painel.rede.post(destino", painel)

        pulso = painel[painel.index("function pulsoDoServidor("):]
        pulso = pulso[:pulso.index("function acordarServidor(")]
        self.assertIn('method: "GET"', pulso)
        self.assertIn("pulsoDoServidor(tentativa + 1)", pulso)

    def test_acorda_o_banco_e_nao_so_o_processo(self):
        """Acordar só o processo troca uma espera longa por uma média.

        O primeiro clique de quem volta ao painel vai consultar o banco,
        e abrir conexão nova com o Supabase custa segundos.
        """
        self.assertIn('fetch("/pronto/?painel=1"', self.painel())

    def test_get_recente_elimina_despertar_redundante_antes_do_post(self):
        painel = self.painel()
        navegacao = (
            RAIZ / "static" / "interno" / "ls-soft-navigation.js"
        ).read_text(encoding="utf-8")

        self.assertIn("marcarSucesso: function ()", painel)
        self.assertIn("Painel.rede.marcarSucesso();", painel)
        self.assertIn("window.Painel.rede.marcarSucesso();", navegacao)

    def test_a_espera_cabe_numa_partida_a_frio(self):
        """Eram ~2 segundos: o bastante para uma oscilação de rede, e
        muito pouco para o caso que motivou tudo isto.

        Uma instância suspensa leva de vinte a sessenta segundos para
        voltar. Desistindo aos dois, o painel decidia que o servidor não
        vinha justamente enquanto ele estava subindo.
        """
        painel = self.painel()
        self.assertIn(
            "var ESPERAS_DO_PULSO = [600, 1400, 3000, 5000, 8000, 11000, 12000];",
            painel,
        )
        # Somadas, passam de quarenta segundos.
        soma = 600 + 1400 + 3000 + 5000 + 8000 + 11000 + 12000
        self.assertGreater(soma, 40000)

    def test_desistir_de_acordar_nao_barra_a_gravacao(self):
        """Barrar transformaria uma espera em uma parede.

        Recusar fazia sentido enquanto a espera era de dois segundos.
        Agora que ela cobre uma partida a frio inteira, desistir depois
        dela e ainda barrar o envio entrega "tente de novo" a quem
        esperou quarenta segundos sem nada ter sido tentado.
        """
        painel = self.painel()
        post = painel[painel.index("post: function (destino, opcoes)"):]
        post = post[:post.index("/* Mantém a instância pronta")]

        self.assertIn("return false;", post)
        self.assertNotIn("Nada foi enviado", post)

    def test_o_pulso_so_bate_com_a_aba_visivel(self):
        """Aba escondida não gera tráfego; ao voltar, acorda na hora."""
        painel = self.painel()
        self.assertIn('if (document.visibilityState === "visible") acordarServidor(true)', painel)
        self.assertIn('document.addEventListener("visibilitychange"', painel)
