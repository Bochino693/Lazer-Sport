from django.db import models
from django.contrib.auth.models import User
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
import requests
from cloudinary_storage.storage import MediaCloudinaryStorage
from .utils import calcular_frete_por_cep, buscar_coordenadas, buscar_coordenadas_por_cidade, buscar_dados_cep, geocodificar_endereco


class Prime(models.Model):
    ativo = models.BooleanField(default=True)
    criacao = models.DateTimeField(auto_now_add=True, null=True)
    atualizado = models.DateTimeField(auto_now=True, null=True)

    class Meta:
        abstract = True


class EnderecoEmpresa(Prime):
    nome = models.CharField(max_length=100, default="Fabrica do Pery")

    telefone = models.CharField(
        max_length=20,
        null=True,
        blank=True
    )

    cep = models.CharField(max_length=9)
    rua = models.CharField(max_length=255)
    numero = models.CharField(max_length=20)
    complemento = models.CharField(max_length=255, blank=True, null=True)
    bairro = models.CharField(max_length=100)
    cidade = models.CharField(max_length=100)
    estado = models.CharField(max_length=2)

    latitude = models.DecimalField(
        max_digits=50, decimal_places=30, null=True, blank=True
    )
    longitude = models.DecimalField(
        max_digits=50, decimal_places=30, null=True, blank=True
    )

    def __str__(self):
        return f"{self.nome} - {self.cidade}/{self.estado}"


import re
from django.core.exceptions import ValidationError
from django.db import models
from django.contrib.auth.models import User
from django.db.models import UniqueConstraint


def validar_telefone(value):
    padrao = r'^\(\d{2}\)\d{4,5}-\d{4}$'
    if not re.match(padrao, value):
        raise ValidationError(
            "Telefone deve estar no formato (11)91234-5678 ou (11)1234-5678"
        )


class ClientePerfil(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="perfil"
    )

    nome_completo = models.CharField(
        max_length=150,
        blank=True,
        null=True
    )

    telefone = models.CharField(
        max_length=15,
        validators=[validar_telefone],
        blank=True,
        null=True
    )

    criado_em = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        if self.user:
            return self.user.username
        return f"Perfil #{self.id}"

    def clean(self):
        """
        Evita duplicidade de perfil para o mesmo usuário/email
        """
        if not self.user:
            return

        if ClientePerfil.objects.filter(
                user__username=self.user.username,
                user__email=self.user.email
        ).exclude(pk=self.pk).exists():
            raise ValidationError(
                "Já existe um perfil com esse usuário e email."
            )

    class Meta:
        verbose_name = "Perfil de Cliente"
        verbose_name_plural = "Perfis de Clientes"


class ImagensSite(Prime):
    imagem = models.ImageField(upload_to='imagens_site', blank=True, null=True)

    def __str__(self):
        return f'Imagem {self.id}'

    class Meta:
        verbose_name = "Imagem do Site"
        verbose_name_plural = "Imagens do Site"


class Clientes(Prime):
    descricao_cliente = models.CharField(max_length=120, null=True)
    logo_cliente = models.ImageField(upload_to='logo_clientes/', null=False, blank=False)

    # --- Campos para exibição no mapa de clientes ---
    cep = models.CharField(
        max_length=9, blank=True, null=True,
        help_text="Só para clientes no Brasil. Preenchendo o CEP, cidade/estado e "
                  "coordenadas são preenchidos automaticamente ao salvar (não precisa "
                  "digitar latitude/longitude na mão)."
    )
    rua = models.CharField(max_length=180, blank=True, null=True)
    numero = models.CharField(max_length=20, blank=True, null=True)
    bairro = models.CharField(max_length=100, blank=True, null=True)
    cidade = models.CharField(
        max_length=100, blank=True, null=True,
        help_text="Se não tiver CEP (ex: cliente fora do Brasil), preencha cidade/estado/país "
                  "aqui -- as coordenadas também são calculadas automaticamente por eles."
    )
    estado = models.CharField(
        max_length=2, blank=True, null=True,
        help_text="Sigla da UF (ex: SP). Deixe em branco para clientes fora do Brasil."
    )
    pais = models.CharField(max_length=100, default="Brasil")
    latitude = models.DecimalField(
        max_digits=9, decimal_places=6, blank=True, null=True,
        help_text="Preenchido automaticamente a partir do CEP ou da cidade/país ao salvar. "
                  "Só edite na mão se quiser corrigir uma localização específica."
    )
    longitude = models.DecimalField(
        max_digits=9, decimal_places=6, blank=True, null=True,
        help_text="Preenchido automaticamente a partir do CEP ou da cidade/país ao salvar. "
                  "Só edite na mão se quiser corrigir uma localização específica."
    )
    site_cliente = models.URLField(
        blank=True, null=True,
        help_text="Link do Instagram do cliente. Aparece como \"Visitar Instagram\" no popup do mapa."
    )
    exibir_no_mapa = models.BooleanField(
        default=True,
        help_text="Desmarque para manter o cliente cadastrado sem exibi-lo no mapa público."
    )

    class Precisao(models.TextChoices):
        EXATO = "exato", "Endereço exato"
        RUA = "rua", "Meio da rua"
        BAIRRO = "bairro", "Centro do bairro"
        CIDADE = "cidade", "Centro da cidade"
        MANUAL = "manual", "Informada à mão"

    precisao_local = models.CharField(
        max_length=10, choices=Precisao.choices, blank=True, default="",
        help_text="Até onde a busca automática conseguiu chegar. 'Centro da "
                  "cidade' ou 'Centro do bairro' significa que o alfinete está "
                  "na região, e não no endereço -- nesse caso vale abrir o "
                  "Google Maps, copiar as coordenadas certas e colar acima."
    )

    def __str__(self):
        return self.descricao_cliente

    def save(self, *args, **kwargs):
        # Se tem CEP mas ainda não tem cidade preenchida, busca o
        # endereço completo no ViaCEP -- assim quem cadastra só precisa
        # digitar o CEP, e rua/bairro/cidade/estado saem de graça.
        if self.cep and not self.cidade:
            dados = buscar_dados_cep(self.cep)
            if dados:
                self.rua = self.rua or dados["rua"]
                self.bairro = self.bairro or dados["bairro"]
                self.cidade = dados["cidade"]
                self.estado = dados["estado"]

        # Só tenta geocodificar se ainda não tiver coordenadas -- assim,
        # se alguém digitou latitude/longitude na mão (pra ajustar um
        # ponto específico), isso nunca é sobrescrito automaticamente.
        if not self.latitude or not self.longitude:
            lat, lon, precisao = None, None, None

            if self.cep:
                lat, lon, precisao = geocodificar_endereco(
                    self.cep, self.numero or ""
                )

            if (not lat or not lon) and self.cidade:
                lat, lon = buscar_coordenadas_por_cidade(
                    self.cidade, self.estado or "", self.pais or "Brasil"
                )
                # Sem CEP só dá para chegar na cidade. Guardar isso é o que
                # permite distinguir, depois, um alfinete no endereço de um
                # alfinete no centro do município.
                precisao = "cidade" if lat and lon else None

            if lat and lon:
                self.latitude = lat
                self.longitude = lon
                self.precisao_local = precisao or ""

        elif not self.precisao_local:
            # Coordenada que já veio preenchida sem passar pela busca: só
            # pode ter sido digitada por uma pessoa.
            self.precisao_local = self.Precisao.MANUAL

        super().save(*args, **kwargs)

    class Meta:
        verbose_name = "Cliente"
        verbose_name_plural = "Clientes"
        ordering = ['pais', 'estado', 'cidade', 'descricao_cliente']


class CategoriasBrinquedos(Prime):
    imagem_categoria = models.ImageField(upload_to='categorias/',
                                         null=True, blank=False,
                                         unique=True, storage=MediaCloudinaryStorage())
    nome_categoria = models.CharField(max_length=150, null=True, blank=True)

    def __str__(self):
        return self.nome_categoria

    class Meta:
        verbose_name = "Categoria de Produto"
        verbose_name_plural = "Categorias de Produtos"


class TagsBrinquedos(Prime):
    nome_tags = models.CharField(max_length=180)

    def __str__(self):
        return self.nome_tags

    class Meta:
        verbose_name = "Tag"
        verbose_name_plural = "Tags"


class Estabelecimentos(Prime):
    nome_estabelecimento = models.CharField(max_length=180)
    imagem_estabelecimento = models.ImageField(upload_to='estabelecimentos/',
                                               null=True,
                                               blank=True,
                                               storage=MediaCloudinaryStorage())

    def __str__(self):
        return self.nome_estabelecimento

    class Meta:
        verbose_name = "Estabelecimentos"
        verbose_name_plural = "Estabelecimentos"


def parse_metro(value):
    """
    Converte entradas como "2,19" ou "2.19" ou 2.19 para Decimal('2.19').
    Retorna None se value for None ou vazio.
    Lança InvalidOperation/ValueError se impossível converter.
    """
    if value is None or (isinstance(value, str) and value.strip() == ""):
        return None

    # Se já for Decimal or float or int — converte diretamente
    if isinstance(value, Decimal):
        return value
    if isinstance(value, (int, float)):
        return Decimal(str(value))

    # string: substituir vírgula por ponto, remover espaços
    if isinstance(value, str):
        normalized = value.strip().replace(",", ".")
        try:
            return Decimal(normalized)
        except InvalidOperation:
            raise InvalidOperation(f"Não foi possível converter '{value}' para Decimal.")

    # tipo não esperado
    raise ValueError("Tipo de valor inesperado para parse_metro")


# Substitua as classes Brinquedos e ImagemBrinquedo em core/models.py

class Brinquedos(Prime):
    nome_brinquedo = models.CharField(max_length=150)
    imagem_brinquedo = models.ImageField(
        upload_to="imagens_brinquedos",
        blank=True,
        null=True,
        storage=MediaCloudinaryStorage(),
    )
    descricao = models.CharField(max_length=999)
    valor_brinquedo = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
    )
    avaliacao = models.DecimalField(
        decimal_places=2,
        max_digits=6,
    )

    exibir_na_loja = models.BooleanField(
        default=False,
        help_text=(
            "Marque para este brinquedo aparecer também na Loja. "
            "Peças de reposição, promoções e combos entram na Loja "
            "automaticamente; brinquedos não -- só os marcados aqui."
        ),
    )

    categorias_brinquedos = models.ManyToManyField(
        CategoriasBrinquedos,
        related_name="brinquedos",
    )
    tags = models.ManyToManyField(
        TagsBrinquedos,
        related_name="brinquedos_tags",
    )

    estabelecimentos = models.ManyToManyField(
        Estabelecimentos,
        related_name="brinquedos",
        blank=True,
    )

    voltz = models.CharField(max_length=10)

    altura_m = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        blank=True,
        null=True,
    )
    largura_m = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        blank=True,
        null=True,
    )
    profundidade_m = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        blank=True,
        null=True,
    )

    @property
    def dimensoes_m(self):
        if self.altura_m and self.largura_m and self.profundidade_m:
            return (
                f"Altura {self.altura_m}m x "
                f"Largura {self.largura_m}m x "
                f"Profundidade {self.profundidade_m}m"
            )
        return None

    @property
    def metros_cubicos(self):
        if self.altura_m and self.largura_m and self.profundidade_m:
            a = float(self.altura_m)
            l = float(self.largura_m)
            p = float(self.profundidade_m)
            return round(a * l * p, 6)
        return None

    @property
    def volume_formatado(self):
        if self.metros_cubicos is None:
            return None

        valor = self.metros_cubicos
        valor_formatado = (
            f"{valor:,.2f}"
            .replace(",", "X")
            .replace(".", ",")
            .replace("X", ".")
        )

        if valor_formatado.endswith(",00"):
            valor_formatado = valor_formatado[:-3]

        return f"{valor_formatado} m³"

    @property
    def imagens_ordenadas(self):
        """Galeria pública tipada, limitada a três imagens."""
        return (
            self.imagens_brinquedo
            .filter(tipo__isnull=False)
            .exclude(tipo="")
            .order_by("ordem", "id")[:3]
        )

    @property
    def imagem_perfil(self):
        """Imagem PERFIL / FRENTE, usada como capa em todo o sistema."""
        cache = getattr(self, "_prefetched_objects_cache", {})
        fotos_cache = cache.get("imagens_brinquedo")

        if fotos_cache is not None:
            perfil = next(
                (
                    foto
                    for foto in fotos_cache
                    if getattr(foto, "tipo", None) == "perfil"
                    and getattr(foto, "imagem", None)
                ),
                None,
            )
        else:
            perfil = (
                self.imagens_brinquedo
                .filter(tipo="perfil")
                .order_by("ordem", "id")
                .first()
            )

        if perfil and perfil.imagem:
            return perfil.imagem

        # Compatibilidade temporária com registros antigos.
        if self.imagem_brinquedo:
            return self.imagem_brinquedo

        if fotos_cache is not None:
            primeira = next(
                (
                    foto
                    for foto in sorted(
                        fotos_cache,
                        key=lambda item: (item.ordem, item.id),
                    )
                    if getattr(foto, "imagem", None)
                ),
                None,
            )
        else:
            primeira = self.imagens_brinquedo.order_by("ordem", "id").first()

        if primeira and primeira.imagem:
            return primeira.imagem
        return None

    @property
    def imagem_catalogo(self):
        """Capa oficial do brinquedo: PERFIL / FRENTE."""
        return self.imagem_perfil

    def sincronizar_imagem_legada_com_galeria(self):
        """Mantém o campo legado sincronizado com a imagem PERFIL."""
        if not self.pk or not self.imagem_brinquedo:
            return None

        principal = (
            self.imagens_brinquedo
            .filter(tipo="perfil")
            .order_by("ordem", "id")
            .first()
        )

        if principal is None:
            # Só adota uma foto antiga que ainda não foi classificada.
            # Sem esse filtro, uma galeria sem PERFIL transformava o
            # verso (ou um lado) do brinquedo na capa do catálogo.
            principal = (
                self.imagens_brinquedo
                .filter(tipo__isnull=True, ordem=1)
                .first()
            )

        if principal is None:
            return ImagemBrinquedo.objects.create(
                brinquedo=self,
                imagem=self.imagem_brinquedo.name,
                tipo="perfil",
                ordem=1,
                texto_alternativo=(
                    f"Perfil / frente de {self.nome_brinquedo}"
                ),
            )

        campos = []

        if principal.tipo != "perfil":
            principal.tipo = "perfil"
            campos.append("tipo")

        if principal.ordem != 1:
            principal.ordem = 1
            campos.append("ordem")

        if principal.imagem.name != self.imagem_brinquedo.name:
            principal.imagem = self.imagem_brinquedo.name
            campos.append("imagem")

        if not principal.texto_alternativo:
            principal.texto_alternativo = (
                f"Perfil / frente de {self.nome_brinquedo}"
            )
            campos.append("texto_alternativo")

        if campos:
            campos.append("atualizado")
            principal.save(update_fields=campos)

        return principal

    def __str__(self):
        return self.nome_brinquedo

    class Meta:
        verbose_name = "Brinquedo"
        verbose_name_plural = "Brinquedos"


class ImagemBrinquedo(Prime):
    TIPO_PERFIL = "perfil"
    TIPO_VERSO = "verso"
    TIPO_LADO_DIREITO = "lado_direito"
    TIPO_LADO_ESQUERDO = "lado_esquerdo"

    TIPO_CHOICES = (
        (TIPO_PERFIL, "Perfil / Frente"),
        (TIPO_VERSO, "Verso / Costas"),
        (TIPO_LADO_DIREITO, "Lado direito"),
        (TIPO_LADO_ESQUERDO, "Lado esquerdo"),
    )

    brinquedo = models.ForeignKey(
        Brinquedos,
        on_delete=models.CASCADE,
        related_name="imagens_brinquedo",
        verbose_name="Brinquedo",
    )
    imagem = models.ImageField(
        upload_to="imagens_brinquedos/galeria/",
        storage=MediaCloudinaryStorage(),
        verbose_name="Imagem",
    )
    tipo = models.CharField(
        max_length=20,
        choices=TIPO_CHOICES,
        null=True,
        blank=True,
        db_index=True,
        verbose_name="Tipo da imagem",
    )
    ordem = models.PositiveSmallIntegerField(
        default=1,
        verbose_name="Posição na galeria",
        help_text="A ordem visual é definida pelo tipo da imagem.",
        db_index=True,
    )
    texto_alternativo = models.CharField(
        max_length=180,
        blank=True,
        verbose_name="Descrição da imagem",
        help_text="Descreva o que aparece na foto para acessibilidade e busca.",
    )

    def __str__(self):
        tipo = self.get_tipo_display() if self.tipo else f"Foto {self.ordem}"
        return f"{self.brinquedo} — {tipo}"

    class Meta:
        verbose_name = "Imagem de Brinquedo"
        verbose_name_plural = "Imagens de Brinquedos"
        ordering = ["ordem", "id"]
        indexes = [
            models.Index(
                fields=["brinquedo", "ordem"],
                name="img_brinquedo_ordem_idx",
            )
        ]
        constraints = [
            models.UniqueConstraint(
                fields=["brinquedo", "tipo"],
                name="uniq_imagem_brinquedo_tipo",
            )
        ]




class CategoriaPeca(Prime):
    nome_categoria_peca = models.CharField(max_length=90)

    def __str__(self):
        return self.nome_categoria_peca

    class Meta:
        verbose_name = "Categoria de Peça"
        verbose_name_plural = "Categorias de Peças"


class PecasReposicao(Prime):
    nome = models.CharField(max_length=120)
    categoria_peca = models.ManyToManyField(
        CategoriaPeca,
        related_name='pecas',
        blank=True,
        verbose_name="Categorias"
    )
    preco_venda = models.DecimalField(decimal_places=2, max_digits=9, null=True, blank=True)
    preco_fornecedor = models.DecimalField(decimal_places=2, max_digits=9, null=True, blank=True)
    descricao_peca = models.CharField(max_length=999)

    # ⭐ novo campo
    ganho_potencial = models.DecimalField(
        decimal_places=2,
        max_digits=9,
        null=True,
        blank=True,
        editable=False
    )

    class Meta:
        verbose_name = "Peça de Reposição"
        verbose_name_plural = "Peças de Reposição"

    def __str__(self):
        return self.nome

    # ⭐ helper profissional (mantido)
    @property
    def imagem_principal(self):
        # Meta.ordering deixa a posição 1 na frente e .all() respeita o cache
        # de prefetch_related, sem criar uma consulta extra para cada peça.
        imagens = list(self.imagem_peca_reposicao.all())
        return imagens[0] if imagens else None

    @property
    def imagens_ordenadas(self):
        return self.imagem_peca_reposicao.all()

    # 🚀 SAVE INTELIGENTE
    def save(self, *args, **kwargs):
        # ✅ se tem fornecedor e NÃO tem venda → calcula venda automática
        if self.preco_fornecedor and not self.preco_venda:
            self.preco_venda = (
                    self.preco_fornecedor * Decimal("1.12")
            ).quantize(Decimal("0.01"))

        # ✅ calcula ganho potencial se ambos existirem
        if self.preco_venda and self.preco_fornecedor:
            self.ganho_potencial = (
                    self.preco_venda - self.preco_fornecedor
            ).quantize(Decimal("0.01"))
        else:
            self.ganho_potencial = None

        super().save(*args, **kwargs)


class ImagemPeca(Prime):
    class PosicaoImagem(models.TextChoices):
        FRENTE = "frente", "Frente"
        LADO_DIREITO = "lado_direito", "Lado direito"
        LADO_ESQUERDO = "lado_esquerdo", "Lado esquerdo"
        TRAS = "tras", "Traseira"
        DETALHE = "detalhe", "Detalhe"
        OUTRO = "outro", "Outro"

    posicao = models.CharField(
        max_length=20,
        choices=PosicaoImagem.choices,
        default=PosicaoImagem.FRENTE,
        verbose_name="Posição da imagem",
        db_index=True,
    )

    ordem = models.PositiveSmallIntegerField(
        default=1,
        verbose_name="Posição na galeria",
        help_text="Use 1 para a foto principal, 2 para a segunda e assim por diante.",
        db_index=True,
    )

    imagem = models.ImageField(
        upload_to="pecas_reposicao/",
        verbose_name="Imagem",
        null=True,
        storage=MediaCloudinaryStorage()
    )

    peca_reposicao = models.ForeignKey(
        PecasReposicao,
        on_delete=models.CASCADE,
        related_name="imagem_peca_reposicao",
        verbose_name="Peça"
    )

    class Meta:
        verbose_name = "Imagem de Peça de Reposição"
        verbose_name_plural = "Imagens de Peças de Reposição"
        ordering = ["ordem", "id"]
        indexes = [
            models.Index(
                fields=["peca_reposicao", "ordem"],
                name="img_peca_ordem_idx",
            ),
            models.Index(fields=["peca_reposicao"]),
        ]

    def __str__(self):
        return f" ({self.get_posicao_display()})"

    # 🚨 VALIDAÇÃO: máximo 8 imagens por peça
    def clean(self):
        if self.peca_reposicao_id:
            qs = ImagemPeca.objects.filter(
                peca_reposicao=self.peca_reposicao
            )

            # se estiver editando, exclui a própria instância
            if self.pk:
                qs = qs.exclude(pk=self.pk)

            if qs.count() >= 8:
                raise ValidationError(
                    "Cada peça pode ter no máximo 8 imagens."
                )


class Combos(Prime):
    descricao = models.CharField(max_length=90)
    imagem_combo = models.ImageField(upload_to='combos/', null=True,
                                     blank=True, storage=MediaCloudinaryStorage())
    brinquedos = models.ManyToManyField(
        Brinquedos,
        related_name='combos'
    )
    valor_combo = models.DecimalField(decimal_places=2, max_digits=10)

    def __str__(self):
        return self.descricao

    class Meta:
        verbose_name = "Combo"
        verbose_name_plural = "Combos"


class Promocoes(Prime):
    descricao = models.CharField(max_length=120)
    imagem_promocao = models.ImageField(upload_to='promocoes/', null=True, storage=MediaCloudinaryStorage())
    brinquedos = models.ForeignKey(Brinquedos, related_name='promocoes', on_delete=models.CASCADE)
    preco_promocao = models.DecimalField(decimal_places=2, max_digits=10, null=True)

    def __str__(self):
        return self.descricao

    class Meta:
        verbose_name = "Promoção"
        verbose_name_plural = "Promoções"


class Cupom(Prime):
    codigo = models.CharField(max_length=12)
    desconto_percentual = models.DecimalField(decimal_places=2, max_digits=10)
    brinquedo = models.ForeignKey(Brinquedos, on_delete=models.CASCADE, related_name='cupom', null=True)
    categoria = models.ForeignKey(CategoriasBrinquedos, on_delete=models.CASCADE, related_name='categoria', null=True)
    cliente = models.ManyToManyField(
        ClientePerfil,
        related_name='cupons',
        blank=True,
        help_text="Somente perfis de cliente podem receber cupons exclusivos.",
    )
    quantidade_uso = models.IntegerField(default=1, null=True)
    todos_usuarios = models.BooleanField(
        default=True,
        help_text=(
            "Quando ativo, qualquer cliente pode usar o cupom. "
            "Quando desativado, somente os clientes selecionados podem usar."
        ),
    )
    exibir_na_vitrine = models.BooleanField(
        "Exibir na área de parceiros",
        default=False,
        help_text=(
            "Mostra o código como benefício público no site. "
            "Cupons pessoais nunca aparecem para outros clientes."
        ),
    )
    reutilizavel = models.BooleanField(
        default=False,
        help_text="Permite que o mesmo cliente use este cupom em mais de um pedido.",
    )
    data_expiracao = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Data e horário após os quais o cupom deixa de ser aceito.",
    )

    def __str__(self):
        return self.codigo

    class Meta:
        verbose_name = "Cupom de Desconto"
        verbose_name_plural = "Cupons de Desconto"


class BrinquedosProjeto(Prime):
    nome_brinquedo_projeto = models.CharField(max_length=150)
    descricao = models.CharField(max_length=999)

    def __str__(self):
        return self.nome_brinquedo_projeto

    class Meta:
        verbose_name = "Brinquedo Projetado"
        verbose_name_plural = "Brinquedos Projetados"


class ImagemProjetoBrinquedo(Prime):
    brinquedo = models.ForeignKey(
        BrinquedosProjeto,
        on_delete=models.CASCADE,
        related_name='imagens_brinquedo_projeto'
    )
    imagem = models.ImageField(upload_to='projetos/', storage=MediaCloudinaryStorage())
    legenda = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return f"Imagem de {self.brinquedo.nome_brinquedo_projeto}"

    class Meta:
        verbose_name = "Imagem do Brinquedo Projetado"
        verbose_name_plural = "Imagens dos Brinquedos Projetados"


class Projetos(models.Model):
    titulo = models.CharField(max_length=200)
    descricao = models.TextField()
    brinquedo_projetado = models.OneToOneField(
        BrinquedosProjeto,
        related_name='projeto',
        on_delete=models.CASCADE,
        null=True
    )

    def __str__(self):
        return self.titulo

    class Meta:
        verbose_name = "Projeto"
        verbose_name_plural = "Projetos"


class Eventos(models.Model):
    titulo = models.CharField(max_length=200)
    descricao = models.TextField()
    brinquedos = models.ManyToManyField(
        Brinquedos,
        related_name='eventos_brinquedos'
    )

    def __str__(self):
        return self.titulo

    class Meta:
        verbose_name = "Evento"
        verbose_name_plural = "Eventos"


class ImagemEvento(models.Model):
    evento = models.ForeignKey(  # ✔ CORRETO AGORA
        Eventos,
        on_delete=models.CASCADE,
        related_name='imagens_evento',
        null=True

    )
    imagem = models.ImageField(upload_to='eventos/', storage=MediaCloudinaryStorage())
    legenda = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return f"Imagem de {self.evento.titulo}"

    class Meta:
        verbose_name = "Imagem do Evento"
        verbose_name_plural = "Imagens dos Eventos"


class BrinquedoSobMedida(models.Model):
    brinquedo_original = models.ForeignKey(Brinquedos, on_delete=models.CASCADE)
    altura = models.DecimalField(max_digits=10, decimal_places=2)
    largura = models.DecimalField(max_digits=10, decimal_places=2)
    profundidade = models.DecimalField(max_digits=10, decimal_places=2)
    valor_calculado = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.brinquedo_original.nome_brinquedo

    class Meta:
        verbose_name = "Brinquedo Sob Medida"
        verbose_name_plural = "Brinquedos Sob Medida"


class Carrinho(Prime):
    cliente = models.ForeignKey(
        ClientePerfil,
        on_delete=models.CASCADE,
        related_name='carrinhos',
        null=True
    )

    cupom = models.ForeignKey(
        Cupom,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='carrinhos'
    )

    TIPO_ENVIO = [
        ('frete', 'Frete'),
        ('retirada', 'Retirada'),
    ]

    tipo_envio = models.CharField(
        max_length=30,
        choices=TIPO_ENVIO,
        default='frete'
    )

    cpf_cnpj = models.CharField(
        max_length=18,
        null=True,
        blank=True
    )

    mp_payment_id = models.CharField(max_length=100, null=True, blank=True)

    @property
    def total_bruto(self):
        total = sum(
            (item.subtotal for item in self.itens.all()),
            Decimal("0.00")
        )
        return total.quantize(Decimal("0.01"))

    @property
    def valor_desconto(self):
        if not self.cupom:
            return Decimal("0.00")

        percentual = self.cupom.desconto_percentual
        desconto = (self.total_bruto * percentual) / Decimal("100")

        return desconto.quantize(Decimal("0.01"))

    @property
    def total_liquido(self):
        return (self.total_bruto - self.valor_desconto).quantize(Decimal("0.01"))

    @property
    def valor_frete(self):
        if self.tipo_envio != "frete":
            return Decimal("0.00")
        try:
            return self.frete.valor or Decimal("0.00")
        except Frete.DoesNotExist:
            return Decimal("0.00")

    @property
    def total_final(self):
        return (self.total_liquido + self.valor_frete).quantize(Decimal("0.01"))

    def __str__(self):
        if self.cliente and self.cliente.user:
            return f"Carrinho de {self.cliente.user.username}"
        return f"Carrinho #{self.id}"


class ItemCarrinho(Prime):
    carrinho = models.ForeignKey(
        Carrinho,
        on_delete=models.CASCADE,
        related_name='itens'
    )

    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()

    item = GenericForeignKey('content_type', 'object_id')

    quantidade = models.PositiveIntegerField(default=1)

    @property
    def preco_unitario(self):

        if hasattr(self.item, 'valor_brinquedo'):
            return self.item.valor_brinquedo

        if hasattr(self.item, 'valor_combo'):
            return self.item.valor_combo

        if hasattr(self.item, 'preco_promocao'):
            return self.item.preco_promocao

        if hasattr(self.item, 'preco_venda'):
            return self.item.preco_venda or 0

        return 0

    @property
    def subtotal(self):

        preco = Decimal(self.preco_unitario or 0)

        total = preco * Decimal(self.quantidade)

        return total.quantize(
            Decimal("0.01"),
            rounding=ROUND_HALF_UP
        )

    def __str__(self):
        return f"{self.item} (x{self.quantidade})"


from django.db import transaction


class Frete(Prime):
    carrinho = models.OneToOneField(
        Carrinho,
        on_delete=models.CASCADE,
        related_name='frete',
        null=True
    )

    cep = models.CharField(max_length=9, null=True, blank=True)

    rua = models.CharField(max_length=180, null=True, blank=True)
    bairro = models.CharField(max_length=90, null=True, blank=True)
    cidade = models.CharField(max_length=90, null=True, blank=True)
    estado = models.CharField(max_length=90, null=True, blank=True)
    numero = models.CharField(max_length=20, null=True, blank=True)

    latitude = models.DecimalField(
        max_digits=9, decimal_places=6, null=True, blank=True,
        help_text="Geocodificado automaticamente a partir do CEP quando o frete é calculado."
    )
    longitude = models.DecimalField(
        max_digits=9, decimal_places=6, null=True, blank=True,
        help_text="Geocodificado automaticamente a partir do CEP quando o frete é calculado."
    )

    valor = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    distancia_km = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        null=True,
        blank=True
    )

    tempo_estimado_min = models.PositiveIntegerField(
        null=True,
        blank=True
    )

    def __str__(self):
        return f"Frete carrinho #{self.carrinho.id} - R$ {self.valor}"


class Pedido(Prime):
    STATUS_CHOICES = (
        ('aguardando_pagamento', 'Aguardando pagamento'),
        ('pago', 'Pago'),
        ('em_preparacao', 'Em preparação'),
        ('saiu_entrega', 'Saiu para entrega'),
        ('finalizado', 'Finalizado'),
        ('cancelado', 'Cancelado'),
    )

    TIPO_ENVIO = Carrinho.TIPO_ENVIO

    carrinho_origem = models.ForeignKey(
        Carrinho,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='pedidos_gerados'
    )

    impresso = models.BooleanField(default=False, null=True, blank=True)

    def finalizar(self, forma_pagamento=None):
        """
        Finaliza o pedido e cria a venda de forma segura.
        """
        if self.status == 'finalizado':
            return self.venda if hasattr(self, 'venda') else None

        with transaction.atomic():
            # atualiza status
            self.status = 'finalizado'
            self.save(update_fields=['status'])

            # cria venda se não existir
            venda, created = Venda.objects.get_or_create(
                pedido=self,
                defaults={
                    'valor_pago': self.total_liquido,
                    'forma_pagamento': forma_pagamento,
                    'confirmado': True
                }
            )

            return venda

    FORMA_PAGAMENTO_CHOICES = (
        ('pix', 'PIX'),
        ('credito', 'Cartão de Crédito'),
        ('debito', 'Cartão de Débito'),
    )

    cliente = models.ForeignKey(
        ClientePerfil,
        on_delete=models.SET_NULL,
        related_name='pedidos',
        null=True, blank=True
    )

    status = models.CharField(
        max_length=30,
        choices=STATUS_CHOICES,
        default='aguardando_pagamento'
    )

    # Modo de envio NO MOMENTO em que o pedido foi criado. Precisa ser
    # gravado aqui (e não só lido de carrinho_origem.tipo_envio) porque
    # o Carrinho é reaproveitado pelo cliente entre compras -- se ele
    # mudar de "retirada" para "frete" (ou vice-versa) num pedido novo,
    # os pedidos antigos não podem mudar de tipo junto.
    tipo_envio = models.CharField(
        max_length=30,
        choices=TIPO_ENVIO,
        default='frete'
    )

    rua = models.CharField(max_length=180, null=True, blank=True)
    numero = models.CharField(max_length=20, null=True, blank=True)
    bairro = models.CharField(max_length=90, null=True, blank=True)
    cidade = models.CharField(max_length=90, null=True, blank=True)
    estado = models.CharField(max_length=2, null=True, blank=True)
    cep = models.CharField(max_length=9, null=True, blank=True)

    # Coordenadas do endereço de entrega e métricas de frete, também
    # congeladas no momento da criação do pedido -- pela mesma razão
    # acima: o Frete pertence ao Carrinho reaproveitável, então sem
    # esse snapshot um pedido antigo passaria a "herdar" a distância e
    # o tempo estimado da encomenda mais recente do cliente.
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    distancia_km = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    tempo_estimado_min = models.PositiveIntegerField(null=True, blank=True)

    valor_frete = models.DecimalField(max_digits=10, decimal_places=2, null=True, default=0)
    # 🔒 snapshot financeiro
    total_bruto = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    valor_desconto = models.DecimalField(max_digits=10, decimal_places=2, default=0, null=True, blank=True)
    total_liquido = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    total_final = models.DecimalField(max_digits=10, decimal_places=2, default=0, null=True)

    forma_pagamento = models.CharField(
        max_length=20,
        choices=FORMA_PAGAMENTO_CHOICES,
        null=True,
        blank=True
    )

    mp_payment_id = models.CharField(
        max_length=100,
        null=True,
        blank=True,
        db_index=True
    )
    mp_status = models.CharField(max_length=50, null=True, blank=True)

    cupom_codigo = models.CharField(max_length=20, blank=True, null=True)
    cupom_percentual = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    # O pagamento pode ser confirmado pelo webhook com o cliente já fora do
    # site. Estes dois campos guardam o que ainda falta entregar a ele:
    # o aviso na tela e o e-mail. Ambos são marcados só depois de dar certo,
    # então uma falha de rede ou de SMTP apenas adia a entrega — nunca a
    # perde, e nunca duplica.
    confirmacao_notificada = models.BooleanField(
        "Confirmação já exibida ao cliente",
        default=False,
        db_index=True,
    )
    email_confirmacao_enviado = models.BooleanField(
        "E-mail de confirmação enviado",
        default=False,
    )

    # Assinatura do carrinho no instante em que o pedido foi reservado.
    # É ela que amarra a cobrança do Mercado Pago a este pedido: o carrinho
    # é esvaziado na reserva, então a conferência de divergência não pode
    # mais depender de reler os itens do carrinho.
    mp_fingerprint = models.CharField(
        "Assinatura da cobrança",
        max_length=64,
        blank=True,
        default="",
    )

    @property
    def aguardando_pagamento(self):
        return self.status == "aguardando_pagamento"

    @transaction.atomic
    def devolver_ao_carrinho(self):
        """Desfaz a reserva: os itens voltam para o carrinho de origem.

        Chamado quando a cobrança é recusada, cancelada ou expira. Sem isto,
        um Pix abandonado deixaria o cliente sem carrinho e sem pedido pago —
        que é justamente o susto que reservar cedo poderia causar.
        """
        if self.status not in ("aguardando_pagamento", "cancelado"):
            raise ValueError(
                "Só um pedido ainda não pago pode voltar para o carrinho."
            )

        carrinho = self.carrinho_origem
        if carrinho is None:
            raise ValueError("Este pedido não tem carrinho de origem.")

        for item in self.itens.all():
            if not item.content_type_id or not item.object_id:
                # Produto excluído do catálogo depois da reserva: não há o
                # que devolver, e recriar a linha deixaria o carrinho com um
                # item fantasma sem preço.
                continue

            linha, criado = ItemCarrinho.objects.get_or_create(
                carrinho=carrinho,
                content_type_id=item.content_type_id,
                object_id=item.object_id,
                defaults={"quantidade": item.quantidade},
            )
            if not criado:
                linha.quantidade += item.quantidade
                linha.save(update_fields=["quantidade"])

        self.status = "cancelado"
        self.mp_payment_id = None
        self.save(update_fields=["status", "mp_payment_id", "atualizado"])

        # A cobrança morreu junto com a reserva.
        Carrinho.objects.filter(pk=carrinho.pk).update(mp_payment_id=None)
        return carrinho

    observacoes = models.TextField(blank=True)

    def save(self, *args, **kwargs):

        if self.total_liquido is None:
            self.total_liquido = Decimal("0.00")

        if self.valor_frete is None:
            self.valor_frete = Decimal("0.00")

        # total final = liquido + frete
        self.total_final = (
                Decimal(self.total_liquido or 0) +
                Decimal(self.valor_frete or 0)
        )

        super().save(*args, **kwargs)

    @classmethod
    def criar_do_carrinho(cls, carrinho):

        frete = None
        if carrinho.tipo_envio == "frete":
            try:
                frete = carrinho.frete
            except Frete.DoesNotExist:
                frete = None

        valor_frete = (
            carrinho.valor_frete
            if frete
            else Decimal("0.00")
        )

        pedido = cls.objects.create(
            carrinho_origem=carrinho,
            cliente=carrinho.cliente,

            tipo_envio=carrinho.tipo_envio,

            total_bruto=carrinho.total_bruto,
            valor_desconto=carrinho.valor_desconto,
            total_liquido=carrinho.total_liquido,
            valor_frete=valor_frete,
            total_final=carrinho.total_final,

            cep=frete.cep if frete else None,
            rua=frete.rua if frete else None,
            numero=frete.numero if frete else None,
            bairro=frete.bairro if frete else None,
            cidade=frete.cidade if frete else None,
            estado=frete.estado if frete else None,
            latitude=frete.latitude if frete else None,
            longitude=frete.longitude if frete else None,
            distancia_km=frete.distancia_km if frete else None,
            tempo_estimado_min=frete.tempo_estimado_min if frete else None,

            cupom_codigo=carrinho.cupom.codigo if carrinho.cupom else None,
            cupom_percentual=carrinho.cupom.desconto_percentual if carrinho.cupom else None,
        )

        return pedido

    def __str__(self):
        if self.cliente and self.cliente.user:
            return f"Pedido #{self.id} - {self.cliente.user.username}"
        return f"Pedido #{self.id}"


class ItemPedido(Prime):
    pedido = models.ForeignKey(
        Pedido,
        on_delete=models.CASCADE,
        related_name='itens'
    )

    # referência apenas histórica
    content_type = models.ForeignKey(ContentType, on_delete=models.SET_NULL, null=True)
    object_id = models.PositiveIntegerField(null=True)
    item_original = GenericForeignKey('content_type', 'object_id')

    nome_item = models.CharField(max_length=255)
    tipo_item = models.CharField(
        max_length=30,
        choices=(
            ('brinquedo', 'Brinquedo'),
            ('combo', 'Combo'),
            ('promocao', 'Promoção'),
            ('pecas', 'Peças'),
        )
    )

    preco_unitario = models.DecimalField(max_digits=10, decimal_places=2)
    quantidade = models.PositiveIntegerField()
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.nome_item} (x{self.quantidade})"


class Venda(Prime):
    pedido = models.OneToOneField(
        Pedido,
        on_delete=models.PROTECT,
        related_name='venda',
        null=True
    )

    valor_pago = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    forma_pagamento = models.CharField(max_length=30,
                                       choices=(
                                           ('pix', 'PIX'),
                                           ('cartao', 'Cartão'),
                                           ('dinheiro', 'Dinheiro'),
                                           ('whatsapp', 'WhatsApp'),
                                       ),
                                       null=True

                                       )

    confirmado = models.BooleanField(default=False)
    cpf = models.CharField(max_length=16, null=True)

    def __str__(self):
        return f"Venda do Pedido #{self.pedido.id}"


class Manutencao(models.Model):
    STATUS_CHOICES = [
        ('P', 'Pendente'),
        ('A', 'Em andamento'),
        ('C', 'Concluída'),
        ('X', 'cancelada'),
    ]

    brinquedo = models.ForeignKey(
        Brinquedos,
        on_delete=models.SET_NULL,
        related_name='brinquedo_manutencoes',
        null=True,
        blank=True
    )
    brinquedo_nao_listado = models.BooleanField(
        default=False,
        help_text="Marque quando o equipamento não estiver no catálogo."
    )
    brinquedo_descricao_livre = models.CharField(
        max_length=180,
        blank=True,
        default="",
        help_text=(
            "Identificação manual para equipamentos não catalogados, "
            "não registrados ou antigos."
        )
    )
    descricao = models.TextField(max_length=999)

    usuario = models.ForeignKey(
        ClientePerfil,
        on_delete=models.CASCADE,
        related_name='manutencoes'
    )

    telefone_contato = models.CharField(
        max_length=20,
        help_text="Telefone para contato",
        null=True
    )

    cep = models.CharField(
        max_length=9,
        help_text="Formato: 00000-000",
        null=True
    )
    endereco = models.CharField(max_length=255, null=True)
    numero = models.CharField(max_length=20, null=True)
    complemento = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )
    bairro = models.CharField(max_length=100, null=True, blank=True)
    cidade = models.CharField(max_length=100, null=True, blank=True)
    estado = models.CharField(max_length=2, null=True, blank=True)

    status = models.CharField(
        max_length=1,
        choices=STATUS_CHOICES,
        default='P'
    )
    criado_em = models.DateTimeField(auto_now_add=True)
    atualizada_em = models.DateTimeField(auto_now=True, null=True)

    @property
    def nome_equipamento(self):
        if self.brinquedo_id:
            return str(self.brinquedo)

        descricao_livre = (self.brinquedo_descricao_livre or "").strip()
        if descricao_livre:
            return descricao_livre

        return "Equipamento antigo ou não catalogado"

    def __str__(self):
        return f"{self.nome_equipamento} - {self.get_status_display()}"


class ManutencaoImagem(models.Model):
    manutencao = models.ForeignKey(
        Manutencao,
        on_delete=models.CASCADE,
        related_name='imagens'
    )
    imagem = models.ImageField(upload_to='manutencoes/')


class ListaDesejos(Prime):
    brinquedos = models.ManyToManyField(Brinquedos, related_name='lista_desejos')

    def __str__(self):
        return self.brinquedos.nome_brinquedo

    class Meta:
        verbose_name = "Lista de Desejo"
        verbose_name_plural = "Lista de Desejos"


class BrinquedoClick(Prime):
    brinquedo_clicado = models.ForeignKey(Brinquedos, on_delete=models.SET_NULL, related_name='clicks_brinquedo',
                                          null=True)
    quantidade_click = models.IntegerField(default=1)

    def __str__(self):
        return self.brinquedo_clicado.nome_brinquedo

    class Meta:
        verbose_name = "Brinquedo Clicado"
        verbose_name_plural = "Brinquedos Clicados"


class ComboClick(Prime):
    combo_clicado = models.ForeignKey(
        Combos,
        on_delete=models.SET_NULL,
        related_name='clicks_combo',
        null=True,
        blank=True
    )

    # Snapshot dos dados (permanece mesmo se apagar)
    descricao_combo = models.CharField(max_length=90, null=True)
    valor_combo = models.DecimalField(max_digits=10, decimal_places=2, null=True)

    quantidade_click = models.IntegerField(default=1)

    def __str__(self):
        return self.descricao_combo

    class Meta:
        verbose_name = "Combo Clicado"
        verbose_name_plural = "Combos Clicados"


class PromocaoClick(Prime):
    promocao = models.ForeignKey(
        Promocoes,
        on_delete=models.SET_NULL,
        related_name='clicks_promocao',
        null=True,
        blank=True
    )

    # SNAPSHOT (permanece após exclusão)
    descricao_promocao = models.CharField(max_length=120, null=True)
    preco_promocao = models.DecimalField(max_digits=10, decimal_places=2, null=True)

    quantidade_click = models.IntegerField(default=1)

    def __str__(self):
        return self.descricao_promocao

    class Meta:
        verbose_name = "Promoção Clicada"
        verbose_name_plural = "Promoções Clicadas"


class CategoriaClick(Prime):
    categoria = models.ForeignKey(
        CategoriasBrinquedos,
        on_delete=models.SET_NULL,
        related_name='clicks_categoria',
        null=True,
        blank=True
    )

    # SNAPSHOT
    nome_categoria = models.CharField(max_length=150, null=True)

    quantidade_click = models.IntegerField(default=1)

    def __str__(self):
        return self.nome_categoria

    class Meta:
        verbose_name = "Categoria Clicada"
        verbose_name_plural = "Categorias Clicadas"


class Favorito(Prime):
    """Curtida e lista de desejos de brinquedos e peças de reposição.

    Não exige login. Sem conta o registro pertence ao dispositivo (uma
    chave gravada em cookie no site, ou enviada pelo cabeçalho
    ``X-Dispositivo`` no aplicativo): vale uma curtida por dispositivo.
    Ao entrar na conta o que estava no dispositivo migra para o usuário e
    passa a valer uma por conta, mesmo que a pessoa troque de aparelho.
    """

    class Tipo(models.TextChoices):
        CURTIDA = "curtida", "Curtida"
        DESEJO = "desejo", "Lista de desejos"

    class Origem(models.TextChoices):
        APP = "app", "Aplicativo"
        SITE = "site", "Site"

    tipo = models.CharField(
        max_length=10,
        choices=Tipo.choices,
        db_index=True,
        verbose_name="Tipo",
    )

    brinquedo = models.ForeignKey(
        Brinquedos,
        on_delete=models.CASCADE,
        related_name="favoritos",
        null=True,
        blank=True,
    )
    peca = models.ForeignKey(
        PecasReposicao,
        on_delete=models.CASCADE,
        related_name="favoritos",
        null=True,
        blank=True,
        verbose_name="Peça de reposição",
    )

    usuario = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="favoritos",
        null=True,
        blank=True,
    )
    dispositivo = models.CharField(
        max_length=64,
        db_index=True,
        blank=True,
        help_text="Chave anônima do aparelho que registrou a interação.",
    )
    origem = models.CharField(
        max_length=6,
        choices=Origem.choices,
        default=Origem.SITE,
        db_index=True,
    )

    class Meta:
        verbose_name = "Curtida / desejo"
        verbose_name_plural = "Curtidas e desejos"
        ordering = ("-criacao", "-id")
        constraints = [
            # Um produto por registro: ou brinquedo, ou peça.
            models.CheckConstraint(
                condition=(
                    models.Q(brinquedo__isnull=False, peca__isnull=True)
                    | models.Q(brinquedo__isnull=True, peca__isnull=False)
                ),
                name="favorito_um_produto_apenas",
            ),
            # Logado: uma por conta, não importa o aparelho.
            models.UniqueConstraint(
                fields=["tipo", "brinquedo", "usuario"],
                condition=models.Q(
                    usuario__isnull=False,
                    brinquedo__isnull=False,
                ),
                name="favorito_brinquedo_por_conta",
            ),
            models.UniqueConstraint(
                fields=["tipo", "peca", "usuario"],
                condition=models.Q(usuario__isnull=False, peca__isnull=False),
                name="favorito_peca_por_conta",
            ),
            # Visitante: uma por aparelho.
            models.UniqueConstraint(
                fields=["tipo", "brinquedo", "dispositivo"],
                condition=models.Q(
                    usuario__isnull=True,
                    brinquedo__isnull=False,
                ),
                name="favorito_brinquedo_por_dispositivo",
            ),
            models.UniqueConstraint(
                fields=["tipo", "peca", "dispositivo"],
                condition=models.Q(usuario__isnull=True, peca__isnull=False),
                name="favorito_peca_por_dispositivo",
            ),
        ]

    def __str__(self):
        return f"{self.get_tipo_display()} — {self.nome_produto}"

    @property
    def produto(self):
        return self.brinquedo or self.peca

    @property
    def nome_produto(self) -> str:
        if self.brinquedo_id and self.brinquedo:
            return self.brinquedo.nome_brinquedo
        if self.peca_id and self.peca:
            return self.peca.nome
        return "Produto removido"


# ======================================================================
# PONTOS, METAS E LOJA DE CUPONS
#
# A ideia em uma frase: o cliente marca o que gosta no aplicativo, isso
# vira ponto, e ponto vira cupom de desconto na loja do site.
#
# POR QUE UM LIVRO-CAIXA, E NÃO UM CONTADOR. Guardar só o saldo esconde
# de onde ele veio -- e um saldo que ninguém consegue explicar é um saldo
# que ninguém confia, nem o cliente nem o atendimento. Cada linha de
# PontoGanho é um fato ("curtiu o brinquedo 12", "chegou a 5 itens na
# lista", "resgatou o cupom X"), e o saldo é a soma delas. Desfazer a
# curtida apaga a linha correspondente: sem isso, curtir e descurtir em
# sequência viraria uma fábrica de pontos.
# ======================================================================

class PontoGanho(Prime):
    """Uma linha do extrato de pontos do cliente."""

    class Origem(models.TextChoices):
        CURTIDA = "curtida", "Curtida no aplicativo"
        META_DESEJO = "meta_desejo", "Meta da lista de desejos"
        META_CURTIDA = "meta_curtida", "Meta de curtidas"
        RESGATE = "resgate", "Resgate de cupom"
        AJUSTE = "ajuste", "Ajuste manual"

    #: Origens recalculadas a partir dos favoritos. As demais são
    #: definitivas -- resgate não se refaz sozinho.
    ORIGENS_AUTOMATICAS = (
        Origem.CURTIDA,
        Origem.META_DESEJO,
        Origem.META_CURTIDA,
    )

    usuario = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="pontos",
    )
    origem = models.CharField(
        max_length=15,
        choices=Origem.choices,
        db_index=True,
    )
    # Identifica o FATO que gerou os pontos: "favorito:12", "desejo:5",
    # "resgate:31". É o que impede pagar duas vezes pela mesma coisa.
    chave = models.CharField(max_length=60)
    pontos = models.IntegerField(
        help_text="Negativo quando o cliente gasta.",
    )
    descricao = models.CharField(max_length=140, blank=True)

    class Meta:
        verbose_name = "Ponto do cliente"
        verbose_name_plural = "Pontos dos clientes"
        ordering = ("-criacao", "-id")
        constraints = [
            models.UniqueConstraint(
                fields=["usuario", "origem", "chave"],
                name="ponto_um_por_fato",
            ),
        ]

    def __str__(self):
        return f"{self.usuario} · {self.pontos:+d} ({self.get_origem_display()})"


class CarteiraPontos(Prime):
    """Saldo do cliente, mantido junto do extrato.

    Existe para duas coisas que a soma não resolve bem: mostrar o saldo
    sem varrer o extrato a cada tela, e travar a linha no resgate
    (`select_for_update`), para dois toques no mesmo botão não gastarem o
    mesmo ponto duas vezes.
    """

    usuario = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="carteira_pontos",
    )
    # Inteiro com sinal de propósito: se o cliente gastar e depois desfazer
    # curtidas, o saldo pode ficar negativo. Preferimos registrar isso a
    # fingir que não aconteceu -- e o resgate já exige saldo suficiente.
    saldo = models.IntegerField(default=0)
    total_ganho = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = "Carteira de pontos"
        verbose_name_plural = "Carteiras de pontos"

    def __str__(self):
        return f"{self.usuario} · {self.saldo} pontos"


class RecompensaCupom(Prime):
    """O que o cliente pode trocar por pontos, na loja do aplicativo."""

    nome = models.CharField(max_length=90)
    descricao = models.CharField(max_length=180, blank=True)
    custo_pontos = models.PositiveIntegerField(
        help_text="Quantos pontos o cliente gasta para resgatar.",
    )
    desconto_percentual = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        help_text="Desconto do cupom gerado, em porcentagem.",
    )
    validade_dias = models.PositiveIntegerField(
        default=30,
        help_text="Dias de validade do cupom depois do resgate.",
    )
    # None = sem limite. O limite é por recompensa, não por cliente.
    estoque = models.PositiveIntegerField(
        null=True,
        blank=True,
        help_text="Quantos ainda podem ser resgatados. Vazio = ilimitado.",
    )
    ordem = models.PositiveSmallIntegerField(
        default=1,
        help_text="Posição na vitrine do aplicativo.",
    )
    exibir_na_vitrine_site = models.BooleanField(
        "Mostrar prévia no site",
        default=True,
        help_text=(
            "Exibe a recompensa na área de parceiros, com aviso de que "
            "o resgate por pontos acontece somente no aplicativo."
        ),
    )

    @property
    def disponivel(self) -> bool:
        return bool(self.ativo) and (self.estoque is None or self.estoque > 0)

    class Meta:
        verbose_name = "Recompensa da loja de pontos"
        verbose_name_plural = "Recompensas da loja de pontos"
        ordering = ("ordem", "custo_pontos", "id")

    def __str__(self):
        return f"{self.nome} ({self.custo_pontos} pts)"


class ResgateCupom(Prime):
    """O cupom que o cliente comprou com pontos.

    O cupom gerado é um `Cupom` de verdade, exclusivo daquele cliente:
    assim ele passa pela mesma validação do carrinho que qualquer outro,
    e o checkout não precisa saber que pontos existem.
    """

    usuario = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="resgates",
    )
    recompensa = models.ForeignKey(
        RecompensaCupom,
        on_delete=models.PROTECT,
        related_name="resgates",
    )
    cupom = models.OneToOneField(
        Cupom,
        on_delete=models.CASCADE,
        related_name="resgate",
    )
    pontos_gastos = models.PositiveIntegerField()
    expira_em = models.DateTimeField()

    class Meta:
        verbose_name = "Resgate de cupom"
        verbose_name_plural = "Resgates de cupons"
        ordering = ("-criacao", "-id")

    def __str__(self):
        return f"{self.usuario} · {self.cupom.codigo}"
