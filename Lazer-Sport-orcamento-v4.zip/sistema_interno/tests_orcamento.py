"""Orçamento visto de dentro: catálogo, cadastro na hora e envio.

O painel responde no subdomínio interno, então todo teste aqui usa
HTTP_HOST="interno.testserver" — sem isso o SubdomainURLMiddleware não
liga `is_interno` e a view devolve um desvio para a loja, que é o mesmo
que o usuário veria.
"""

from datetime import timedelta
from decimal import Decimal

from django.contrib.auth.models import User
from django.core import mail
from django.test import TestCase, override_settings
from django.utils import timezone

from core.models import Brinquedos, CategoriaPeca, CategoriasBrinquedos, PecasReposicao

from .models import Cliente, ItemOrcamento, Orcamento, ProdutoInterno


@override_settings(ALLOWED_HOSTS=["interno.testserver", "testserver"])
class OrcamentoInternoTests(TestCase):

    URL = "/orcamentos/"

    def setUp(self):
        self.gestor = User.objects.create_superuser(
            username="gestor",
            password="senha-segura",
            email="gestor@example.com",
        )
        self.client.force_login(self.gestor)

        self.categoria = CategoriasBrinquedos.objects.create(
            nome_categoria="Infláveis",
        )
        self.brinquedo = Brinquedos.objects.create(
            nome_brinquedo="Cama elástica",
            imagem_brinquedo="imagens_brinquedos/cama-elastica.jpg",
            descricao="Cama elástica 3m",
            valor_brinquedo=Decimal("280.00"),
            avaliacao=Decimal("5.00"),
            voltz="110",
        )

    def post(self, dados):
        return self.client.post(
            self.URL,
            dados,
            HTTP_HOST="interno.testserver",
            HTTP_X_REQUESTED_WITH="XMLHttpRequest",
        )

    # -------------------------------------------------------- catálogo
    def test_tela_busca_catalogo_sob_demanda(self):
        resposta = self.client.get(self.URL, HTTP_HOST="interno.testserver")

        self.assertEqual(resposta.status_code, 200)
        # O catálogo inteiro não é embutido na página: mil itens continuam
        # sendo uma tela leve. O navegador consulta somente quando digita.
        self.assertNotContains(resposta, "opcoesItens")
        self.assertContains(resposta, "Novo brinquedo")

        busca = self.client.get(
            "/orcamentos/itens/buscar/",
            {"q": "cama elastica"},
            HTTP_HOST="interno.testserver",
        )
        self.assertEqual(busca.status_code, 200)
        opcoes = busca.json()["opcoes"]
        self.assertEqual(opcoes[0]["valor"], f"b:{self.brinquedo.id}")
        self.assertEqual(opcoes[0]["rotulo"], "Cama elástica")
        self.assertTrue(opcoes[0]["imagem"])

    def test_busca_nunca_devolve_catalogo_inteiro(self):
        Brinquedos.objects.bulk_create([
            Brinquedos(
                nome_brinquedo=f"Brinquedo festa {numero:03d}",
                descricao="Item para festa",
                avaliacao=Decimal("0.00"),
                voltz="bivolt",
            )
            for numero in range(40)
        ])

        resposta = self.client.get(
            "/orcamentos/itens/buscar/",
            {"q": "festa"},
            HTTP_HOST="interno.testserver",
        )

        self.assertEqual(resposta.status_code, 200)
        self.assertLessEqual(len(resposta.json()["opcoes"]), 24)

    def test_clientes_tambem_sao_buscados_sob_demanda(self):
        cliente = Cliente.objects.create(
            nome_cliente="Escola Girassol",
            telefone="(11) 95555-4444",
        )

        pagina = self.client.get(self.URL, HTTP_HOST="interno.testserver")
        self.assertNotContains(pagina, "opcoesClientes")

        resposta = self.client.get(
            "/orcamentos/clientes/buscar/",
            {"q": "Girassol"},
            HTTP_HOST="interno.testserver",
        )
        opcoes = resposta.json()["opcoes"]
        self.assertEqual(opcoes[0]["valor"], str(cliente.id))

    def test_catalogo_inclui_o_que_nao_esta_na_loja(self):
        """A vitrine é um recorte; orçamento alcança o cadastro inteiro."""
        fora = Brinquedos.objects.create(
            nome_brinquedo="Tobogã antigo",
            descricao="Fora da vitrine",
            avaliacao=Decimal("0.00"),
            voltz="220",
            exibir_na_loja=False,
        )
        resposta = self.client.get(
            "/orcamentos/itens/buscar/",
            {"q": "Tobogã antigo"},
            HTTP_HOST="interno.testserver",
        )
        valores = [item["valor"] for item in resposta.json()["opcoes"]]
        self.assertIn(f"b:{fora.id}", valores)

    def test_item_salvo_fica_ligado_ao_brinquedo(self):
        resposta = self.post({
            "action": "save",
            "nome_cliente": "Fulano",
            "status": Orcamento.Status.RASCUNHO,
            "itens": (
                '[{"descricao":"Cama elástica","brinquedo":"%s",'
                '"quantidade":"2","valor_unitario":"280,00"}]' % self.brinquedo.id
            ),
        })

        self.assertEqual(resposta.status_code, 200)
        item = ItemOrcamento.objects.get()
        self.assertEqual(item.brinquedo, self.brinquedo)
        self.assertIsNone(item.produto)
        self.assertEqual(item.subtotal, Decimal("560.00"))

    def test_salva_valores_e_condicoes_no_formato_brasileiro(self):
        resposta = self.post({
            "action": "save",
            "nome_cliente": "Fulano",
            "status": Orcamento.Status.RASCUNHO,
            "frete": "1.250,90",
            "desconto": "50,00",
            "forma_pagamento": "50% na entrada e 50% na entrega",
            "forma_envio": "Transportadora",
            "itens": (
                '[{"descricao":"Cama elástica","brinquedo":"%s",'
                '"quantidade":"2","valor_unitario":"280,00"}]'
                % self.brinquedo.id
            ),
        })

        self.assertEqual(resposta.status_code, 200)
        orcamento = Orcamento.objects.get()
        self.assertEqual(orcamento.frete, Decimal("1250.90"))
        self.assertEqual(orcamento.desconto, Decimal("50.00"))
        self.assertEqual(orcamento.forma_envio, "Transportadora")

    def test_tela_declara_mascaras_e_quantidade_numerica(self):
        resposta = self.client.get(self.URL, HTTP_HOST="interno.testserver")

        self.assertContains(resposta, 'data-mascara="cep"')
        self.assertContains(resposta, 'data-mascara="telefone"')
        self.assertContains(resposta, 'data-mascara="moeda"')
        self.assertContains(resposta, 'type="number" class="form-control form-control-sm text-end ls-item-quantidade"')

    def test_linha_com_catalogo_e_producao_fica_so_com_o_catalogo(self):
        """São origens exclusivas: gravar as duas criaria item inválido."""
        produto = ProdutoInterno.objects.create(nome="Cama — versão fábrica")

        self.post({
            "action": "save",
            "nome_cliente": "Fulano",
            "status": Orcamento.Status.RASCUNHO,
            "itens": (
                '[{"descricao":"Cama","brinquedo":"%s","produto":"%s",'
                '"quantidade":"1","valor_unitario":"280,00"}]'
                % (self.brinquedo.id, produto.id)
            ),
        })

        item = ItemOrcamento.objects.get()
        self.assertEqual(item.brinquedo, self.brinquedo)
        self.assertIsNone(item.produto)

    def test_item_sem_catalogo_ainda_aceita_produto_de_producao(self):
        produto = ProdutoInterno.objects.create(nome="Máquina de algodão doce")

        self.post({
            "action": "save",
            "nome_cliente": "Fulano",
            "status": Orcamento.Status.RASCUNHO,
            "itens": (
                '[{"descricao":"Algodão doce","produto":"%s",'
                '"quantidade":"1","valor_unitario":"150,00"}]' % produto.id
            ),
        })

        item = ItemOrcamento.objects.get()
        self.assertEqual(item.produto, produto)
        self.assertIsNone(item.brinquedo)

    def test_item_pode_vir_das_pecas_de_reposicao(self):
        peca = PecasReposicao.objects.create(
            nome="Mola de cama elástica",
            descricao_peca="Mola galvanizada",
            preco_venda=Decimal("12.50"),
        )

        resposta = self.post({
            "action": "save",
            "nome_cliente": "Fulano",
            "status": Orcamento.Status.RASCUNHO,
            "itens": (
                '[{"descricao":"Mola galvanizada","peca":"%s",'
                '"quantidade":"8","valor_unitario":"12,50"}]' % peca.id
            ),
        })

        self.assertEqual(resposta.status_code, 200)
        item = ItemOrcamento.objects.get()
        self.assertEqual(item.peca, peca)
        self.assertIsNone(item.brinquedo)
        self.assertIsNone(item.produto)

    # ------------------------------------------- cadastrar sem sair daqui
    def test_cadastra_brinquedo_novo_e_devolve_para_a_linha(self):
        resposta = self.post({
            "action": "brinquedo_novo",
            "nome": "Piscina de bolinhas",
            "valor": "340,00",
            "categoria": self.categoria.id,
        })

        self.assertEqual(resposta.status_code, 200)
        dados = resposta.json()
        self.assertEqual(dados["status"], "sucesso")

        novo = Brinquedos.objects.get(nome_brinquedo="Piscina de bolinhas")
        self.assertEqual(dados["brinquedo"]["id"], novo.id)
        self.assertEqual(dados["brinquedo"]["valor"], "340,00")
        self.assertEqual(novo.valor_brinquedo, Decimal("340.00"))
        self.assertIn(self.categoria, novo.categorias_brinquedos.all())

    def test_brinquedo_novo_nasce_fora_da_vitrine(self):
        """Publicar é decisão de quem cuida do site, com foto e texto."""
        self.post({"action": "brinquedo_novo", "nome": "Touro mecânico"})

        novo = Brinquedos.objects.get(nome_brinquedo="Touro mecânico")
        self.assertFalse(novo.exibir_na_loja)

    def test_nao_duplica_brinquedo_existente(self):
        # A diferença de caixa é só em letra ASCII de propósito. O SQLite
        # destes testes dobra maiúscula/minúscula apenas em ASCII, então
        # "ELÁSTICA" x "elástica" não casaria aqui -- no PostgreSQL da
        # produção casa. Testar com "C"/"c" verifica a regra sem depender
        # de qual banco está rodando.
        resposta = self.post({"action": "brinquedo_novo", "nome": "cama elástica"})

        self.assertEqual(resposta.status_code, 400)
        self.assertEqual(Brinquedos.objects.count(), 1)

    def test_brinquedo_novo_exige_nome(self):
        resposta = self.post({"action": "brinquedo_novo", "nome": "   "})

        self.assertEqual(resposta.status_code, 400)
        self.assertEqual(Brinquedos.objects.count(), 1)

    def test_cadastra_peca_nova_e_devolve_para_a_linha(self):
        categoria = CategoriaPeca.objects.create(nome_categoria_peca="Cama elástica")
        resposta = self.post({
            "action": "peca_nova",
            "nome": "Rede de proteção",
            "preco_venda": "89,90",
            "preco_fornecedor": "50,00",
            "categoria": categoria.id,
            "descricao": "Rede preta para 3,05 m",
        })

        self.assertEqual(resposta.status_code, 200)
        peca = PecasReposicao.objects.get(nome="Rede de proteção")
        self.assertEqual(resposta.json()["peca"]["id"], peca.id)
        self.assertEqual(peca.preco_venda, Decimal("89.90"))
        self.assertIn(categoria, peca.categoria_peca.all())

    # -------------------------------------------------------- envio
    def _orcamento_com_item(self):
        orcamento = Orcamento.objects.create(nome_cliente="Fulano")
        ItemOrcamento.objects.create(
            orcamento=orcamento,
            descricao="Cama elástica",
            brinquedo=self.brinquedo,
            quantidade=1,
            valor_unitario=Decimal("280.00"),
        )
        return orcamento

    def test_enviar_devolve_o_link_do_site_publico(self):
        orcamento = self._orcamento_com_item()

        resposta = self.post({"action": "enviar", "id": orcamento.id})
        dados = resposta.json()

        self.assertEqual(resposta.status_code, 200)
        self.assertIn(orcamento.token, dados["link"])
        # o link é do site do cliente, nunca do subdomínio interno
        self.assertNotIn("interno.", dados["link"])

        orcamento.refresh_from_db()
        self.assertEqual(orcamento.status, Orcamento.Status.ENVIADO)
        self.assertIsNotNone(orcamento.enviado_em)

    @override_settings(DEBUG=False, SITE_URL="interno.lazersport.com.br/")
    def test_link_corrige_dominio_sem_protocolo_e_remove_interno(self):
        orcamento = self._orcamento_com_item()

        resposta = self.post({"action": "enviar", "id": orcamento.id})

        self.assertTrue(
            resposta.json()["link"].startswith(
                "https://lazersport.com.br/orcamento/"
            )
        )

    def test_previa_interna_abre_rascunho_sem_permitir_resposta(self):
        orcamento = self._orcamento_com_item()

        resposta = self.client.get(
            f"/orcamentos/{orcamento.pk}/previa/",
            HTTP_HOST="interno.testserver",
        )

        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "Prévia interna")
        self.assertContains(resposta, "Cama elástica")
        self.assertNotContains(resposta, 'id="formDecisao"')

    def test_enviar_orcamento_vazio_e_recusado(self):
        """Link para uma proposta sem itens é constrangimento na frente do cliente."""
        vazio = Orcamento.objects.create(nome_cliente="Fulano")

        resposta = self.post({"action": "enviar", "id": vazio.id})

        self.assertEqual(resposta.status_code, 400)
        vazio.refresh_from_db()
        self.assertEqual(vazio.status, Orcamento.Status.RASCUNHO)

    def test_reenviar_nao_reescreve_a_data_de_envio(self):
        orcamento = self._orcamento_com_item()

        self.post({"action": "enviar", "id": orcamento.id})
        orcamento.refresh_from_db()
        primeira = orcamento.enviado_em

        self.post({"action": "enviar", "id": orcamento.id})
        orcamento.refresh_from_db()
        self.assertEqual(orcamento.enviado_em, primeira)

    def test_enviar_por_whatsapp_devolve_conversa_pronta(self):
        orcamento = self._orcamento_com_item()

        resposta = self.post({
            "action": "enviar",
            "canal": "whatsapp",
            "whatsapp": "(11) 99999-8888",
            "id": orcamento.id,
        })

        self.assertEqual(resposta.status_code, 200)
        dados = resposta.json()
        self.assertTrue(dados["whatsapp_url"].startswith("https://wa.me/5511999998888"))
        self.assertIn(orcamento.token, dados["whatsapp_url"])
        orcamento.refresh_from_db()
        self.assertEqual(orcamento.whatsapp_cliente, "(11) 99999-8888")

    def test_enviar_por_email_entrega_template_da_marca(self):
        orcamento = self._orcamento_com_item()

        resposta = self.post({
            "action": "enviar",
            "canal": "email",
            "email": "cliente@example.com",
            "id": orcamento.id,
        })

        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(len(mail.outbox), 1)
        self.assertEqual(mail.outbox[0].to, ["cliente@example.com"])
        self.assertIn("Lazer & Sport", mail.outbox[0].subject)
        self.assertIn(orcamento.token, mail.outbox[0].alternatives[0].content)

    @override_settings(
        DEFAULT_FROM_EMAIL="Lazer & Sport <contato@lazersport.com.br>",
        EMAIL_RESPOSTA="vendas@lazersport.com.br",
    )
    def test_email_sai_com_a_marca_e_volta_para_quem_enviou(self):
        orcamento = self._orcamento_com_item()

        self.post({
            "action": "enviar",
            "canal": "email",
            "email": "cliente@example.com",
            "id": orcamento.id,
        })

        enviado = mail.outbox[0]
        self.assertEqual(
            enviado.from_email,
            "Lazer & Sport <contato@lazersport.com.br>",
        )
        # O atendente logado é o primeiro a receber a resposta.
        self.assertIn("vendas@lazersport.com.br", enviado.reply_to)

    def test_email_invalido_nao_marca_como_enviado(self):
        orcamento = self._orcamento_com_item()

        resposta = self.post({
            "action": "enviar",
            "canal": "email",
            "email": "email quebrado",
            "id": orcamento.id,
        })

        self.assertEqual(resposta.status_code, 400)
        orcamento.refresh_from_db()
        self.assertEqual(orcamento.status, Orcamento.Status.RASCUNHO)

    # ------------------------------------------------------- a vencer
    def test_tela_separa_os_que_vencem_em_ate_tres_dias(self):
        perto = Orcamento.objects.create(
            nome_cliente="Vence logo",
            status=Orcamento.Status.ENVIADO,
            validade=timezone.localdate() + timedelta(days=2),
        )
        longe = Orcamento.objects.create(
            nome_cliente="Tem tempo",
            status=Orcamento.Status.ENVIADO,
            validade=timezone.localdate() + timedelta(days=20),
        )
        aprovado = Orcamento.objects.create(
            nome_cliente="Já fechou",
            status=Orcamento.Status.APROVADO,
            validade=timezone.localdate() + timedelta(days=1),
        )

        resposta = self.client.get(self.URL, HTTP_HOST="interno.testserver")
        vencendo = resposta.context["vencendo"]

        self.assertIn(perto, vencendo)
        self.assertNotIn(longe, vencendo)
        # proposta já aprovada não é cobrança pendente
        self.assertNotIn(aprovado, vencendo)

    # -------------------------------------------------------- acesso
    def test_colaborador_sem_gerencia_nao_entra(self):
        operador = User.objects.create_user(
            username="operador",
            password="senha-segura",
            is_staff=True,
        )
        self.client.force_login(operador)

        resposta = self.client.get(self.URL, HTTP_HOST="interno.testserver")

        self.assertEqual(resposta.status_code, 302)
        self.assertIn("producao", resposta["Location"])
